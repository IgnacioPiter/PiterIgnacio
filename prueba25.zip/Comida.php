<?php
require_once "Producto.php";
class Comida extends Producto {

    public $peso;

    public function __construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen,$peso) {
        parent::__construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen,);
        
            $this->peso=$peso;
            return parent::mostarInfo() . " | Peso: " . $this->peso . " P";

    }

}
?>
