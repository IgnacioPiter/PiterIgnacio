<?php
require_once "Producto.php";
class Limpieza extends Producto {
    public $formula_quimica;

    public function __construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen,$formula_quimica) {
        parent::__construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen,);
        
            $this->formula_quimica=$formula_quimica;
    }
}
?>
