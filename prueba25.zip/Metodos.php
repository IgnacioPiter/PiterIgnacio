<?php
require_once "Producto.php";
require_once "Bebida.php";
require_once "Comida.php";
require_once "Limpieza.php";

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $accion = $_POST['accion'];
    $codigo_id = $_POST["codigo_id"];

    function mostrarProducto($producto) {
        return "Código: {$producto['codigo']}, ID: {$producto['id']}, Descripción: {$producto['descripcion']}, Cantidad: {$producto['cantidad']}, Precio Unitario: {$producto['precio_unitario']}, Marca: {$producto['marca']}, País de Origen: {$producto['pais_origen']}<br>";
    }

    switch ($accion) {
        case 'procesar':
         
            $encontrado = false;
            foreach ($productos as $producto) {
                if ($producto['codigo'] === $codigo_id) {
                    echo mostrarProducto($producto);
                    $encontrado = true;
                    break;
                }
            }
            if (!$encontrado) {
                echo "Producto no encontrado por código.";
            }
            break;


    }
        
   
?>