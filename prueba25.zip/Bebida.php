<?php
 require_once "Producto.php";
    Class Bebida extends Producto{
        public $litro;
  

        public function __construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen,$litro){
            parent::__construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen);

            $this->litro=$litro;
        }
   

            public function mostrar() {
                return parent::mostrar() . " | Litros: " . $this->litro . " L";
            }

    }

?>