<?php
    require_once "array.php";
    class Producto {
        public $codigo;
        public $descripcion;
        public $cantidad;
        public $precio_unitario;
        public $marca;
        public $pais_origen;
        
        


            public function __construct($codigo, $descripcion, $cantidad, $precio_unitario, $marca, $pais_origen){

                $this->codigo = $codigo;
                $this->descripcion = $descripcion;
                $this->cantidad = $cantidad;
                $this->precio_unitario = $precio_unitario;
                $this->marca = $marca;
                $this->pais_origen = $pais_origen;
              
              
            }
            
            public function mostarInfo(){
                return;
            }
    
    }

    class Metodos {
        
        public static function obtenerProductoPorCodigo($codigo) {
            foreach (self::$producto as $producto) {
                if ($producto['codigo'] === $codigo) {
                    return $producto; 
                }
            }
            return null;
        }
    
        public static function obtenerPorId($id) {
            foreach (self::$producto as $producto) {
                if ($producto['id'] == $id) {
                    return $producto;
                }
            }
            return null;
        }
    
        public static function obtenerProductosDeArgentina() {
            $productosArgentina = [];
            foreach (self::$producto as $producto) {
                if ($producto['pais_origen'] === "Argentina") {
                    $productosArgentina[] = $producto;
                }
            }
            return $productosArgentina;
        }
    
        public static function mostrarProducto($producto) {
            return "Código: {$producto['codigo']}, Descripción: {$producto['descripcion']}, Cantidad: {$producto['cantidad']}, Precio Unitario: {$producto['precio_unitario']}, Marca: {$producto['marca']}, País de Origen: {$producto['pais_origen']}";
        }
    }
    
    
    
?>
