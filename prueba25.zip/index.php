<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="Metodos.php" method="post">
        <label for="codigo"></label>
        <input type="text" name="codigo" id="codigo">
      
        <br><br>
        <button type="submit" name="accion" value="procesar">Procesar</button>
        <button type="submit" name="accion" value="enviar">Enviar</button>
        <button type="submit" name="accion" value="listar">Listar</button>
    </form>
</body>
</html>

